const express = require('express')
const port = 3000
const app = express()
const bodyParser = require('body-parser')
const fetch = require("node-fetch");
const cors = require('cors');

app.set('view engine', 'pug');
app.set('views', './views')

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))

app.use(express.json()) // for parsing application/json
app.use(express.urlencoded({ extended: true })) // for parsing application/x-www-form-urlencoded

const corsOptions = {
  origin: 'http://localhost:3000',
  optionsSuccessStatus: 200
}
app.use(cors(corsOptions))

app.get('/getdata',(req,res)=>{
  res.render('index')

})
app.post('/getdata',(req,res)=>{
  let search = req.body.search
  let rows = 30;
  fetch("http://localhost:8983/solr/LAM/select",{
    method: 'POST',
    headers: { 
             'Accept': 'application/json',
             'Content-Type': 'application/json'
             },
    body: JSON.stringify({
      "query":`sub_content:${search}`,
      "limit":`${rows}`
  })
})
  .then( res => res.json())
  .then(data => {
    console.log(data),
  res.render('index',{
    datas : data.response.docs,
    value:req.body.search

  })}
  )
  .catch(err => console.log(err))
})
//pagination



    app.listen(port, () => console.log(`Server listening on port ${port}!`))